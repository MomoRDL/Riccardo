Ciao Love!!!
npm i
npm run dev